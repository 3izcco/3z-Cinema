import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Get all active category pricing
export const getActiveCategoryPricing = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db
      .query("categoryPricing")
      .withIndex("by_active", (q) => q.eq("isActive", true))
      .collect();
  },
});

// Get all category pricing (admin only)
export const getAllCategoryPricing = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    return await ctx.db.query("categoryPricing").collect();
  },
});

// Initialize default category pricing
export const initializeCategoryPricing = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    // Check if category pricing already exists
    const existingPricing = await ctx.db.query("categoryPricing").collect();
    if (existingPricing.length > 0) {
      return; // Already initialized
    }

    // Create default category pricing
    const defaultCategories = [
      {
        category: "Standard",
        extraPrice: 0,
        description: "Standard theater experience with comfortable seating and digital sound",
        isActive: true,
      },
      {
        category: "Premium",
        extraPrice: 5,
        description: "Premium experience with reclining seats, enhanced sound, and premium amenities",
        isActive: true,
      },
      {
        category: "IMAX",
        extraPrice: 10,
        description: "Ultimate cinema experience with IMAX screen, immersive sound, and premium seating",
        isActive: true,
      },
    ];

    for (const category of defaultCategories) {
      await ctx.db.insert("categoryPricing", category);
    }
  },
});

// Update category pricing (admin only)
export const updateCategoryPricing = mutation({
  args: {
    categoryId: v.id("categoryPricing"),
    extraPrice: v.optional(v.number()),
    description: v.optional(v.string()),
    isActive: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    const { categoryId, ...updates } = args;
    
    // Remove undefined values
    const cleanUpdates = Object.fromEntries(
      Object.entries(updates).filter(([_, value]) => value !== undefined)
    );

    await ctx.db.patch(categoryId, cleanUpdates);
    return categoryId;
  },
});
