import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  // Movies table
  movies: defineTable({
    title: v.string(),
    description: v.string(),
    duration: v.number(), // in minutes
    genre: v.string(),
    posterUrl: v.optional(v.string()),
    posterId: v.optional(v.id("_storage")),
    baseTicketPrice: v.optional(v.number()), // base price
    ticketPrice: v.optional(v.number()), // legacy field for migration
    isActive: v.boolean(),
    rating: v.optional(v.string()), // PG, PG-13, R, etc.
    director: v.optional(v.string()),
    cast: v.optional(v.array(v.string())),
  }).index("by_active", ["isActive"]),

  // Theaters table
  theaters: defineTable({
    name: v.string(),
    capacity: v.number(),
    category: v.optional(v.string()), // "Premium", "Standard", "IMAX"
    features: v.optional(v.array(v.string())), // ["IMAX", "Dolby Atmos", "3D", etc.]
    isActive: v.boolean(),
  }).index("by_active", ["isActive"])
    .index("by_category", ["category"]),

  // Category pricing table
  categoryPricing: defineTable({
    category: v.string(), // "Premium", "Standard", "IMAX"
    extraPrice: v.number(), // additional price for this category
    description: v.optional(v.string()),
    isActive: v.boolean(),
  }).index("by_category", ["category"])
    .index("by_active", ["isActive"]),

  // Showtimes table
  showtimes: defineTable({
    movieId: v.id("movies"),
    theaterId: v.id("theaters"),
    startTime: v.string(), // ISO string
    endTime: v.string(), // ISO string
    availableSeats: v.number(),
    totalSeats: v.number(),
    specialPricing: v.optional(v.number()), // override price for special events
    isActive: v.boolean(),
  }).index("by_movie", ["movieId"])
    .index("by_theater", ["theaterId"])
    .index("by_movie_and_time", ["movieId", "startTime"])
    .index("by_active", ["isActive"]),

  // Bookings table
  bookings: defineTable({
    userId: v.optional(v.id("users")), // optional for anonymous bookings
    movieId: v.id("movies"),
    showtimeId: v.id("showtimes"),
    theaterId: v.id("theaters"),
    seats: v.array(v.string()), // seat numbers like "A1", "B5"
    basePrice: v.optional(v.number()), // movie base price
    categoryPrice: v.optional(v.number()), // category extra price
    totalAmount: v.number(), // final total price
    paymentMethod: v.string(),
    paymentStatus: v.string(), // "pending", "completed", "failed"
    bookingReference: v.string(),
    qrCode: v.optional(v.string()),
    qrCodeData: v.optional(v.object({
      movieName: v.string(),
      theaterName: v.string(),
      category: v.string(),
      finalPrice: v.number(),
      bookingId: v.string(),
      showtime: v.string(),
      seats: v.array(v.string()),
    })),
    customerInfo: v.optional(v.object({
      name: v.string(),
      email: v.string(),
      phone: v.optional(v.string()),
    })), // for anonymous bookings
    isAnonymous: v.boolean(),
  }).index("by_user", ["userId"])
    .index("by_showtime", ["showtimeId"])
    .index("by_reference", ["bookingReference"])
    .index("by_anonymous", ["isAnonymous"]),

  // User profiles (extends auth users)
  userProfiles: defineTable({
    userId: v.id("users"),
    role: v.string(), // "admin" or "customer"
    firstName: v.optional(v.string()),
    lastName: v.optional(v.string()),
    phone: v.optional(v.string()),
    preferences: v.optional(v.object({
      favoriteGenres: v.optional(v.array(v.string())),
      preferredTheater: v.optional(v.id("theaters")),
      notifications: v.optional(v.boolean()),
    })),
  }).index("by_user", ["userId"])
    .index("by_role", ["role"]),

  // Seat reservations (temporary holds during booking process)
  seatReservations: defineTable({
    showtimeId: v.id("showtimes"),
    seatNumber: v.string(),
    userId: v.optional(v.id("users")),
    sessionId: v.string(), // for anonymous users
    expiresAt: v.number(), // timestamp
  }).index("by_showtime", ["showtimeId"])
    .index("by_user", ["userId"])
    .index("by_session", ["sessionId"])
    .index("by_expires", ["expiresAt"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
