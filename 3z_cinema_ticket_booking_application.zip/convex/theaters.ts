import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Get all active theaters
export const listActiveTheaters = query({
  args: {},
  handler: async (ctx) => {
    const theaters = await ctx.db
      .query("theaters")
      .withIndex("by_active", (q) => q.eq("isActive", true))
      .collect();

    return Promise.all(
      theaters.map(async (theater) => {
        // Get category pricing for this theater
        let categoryPricing = null;
        if (theater.category) {
          categoryPricing = await ctx.db
            .query("categoryPricing")
            .withIndex("by_category", (q) => q.eq("category", theater.category!))
            .filter((q) => q.eq(q.field("isActive"), true))
            .unique();
        }

        return {
          ...theater,
          categoryPricing,
        };
      })
    );
  },
});

// Get all theaters (admin only)
export const listAllTheaters = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    const theaters = await ctx.db.query("theaters").collect();
    
    return Promise.all(
      theaters.map(async (theater) => {
        // Get category pricing for this theater
        let categoryPricing = null;
        if (theater.category) {
          categoryPricing = await ctx.db
            .query("categoryPricing")
            .withIndex("by_category", (q) => q.eq("category", theater.category!))
            .filter((q) => q.eq(q.field("isActive"), true))
            .unique();
        }

        return {
          ...theater,
          categoryPricing,
        };
      })
    );
  },
});

// Get theater by ID
export const getTheaterById = query({
  args: { theaterId: v.id("theaters") },
  handler: async (ctx, args) => {
    const theater = await ctx.db.get(args.theaterId);
    if (!theater) return null;

    // Get category pricing for this theater
    let categoryPricing = null;
    if (theater.category) {
      categoryPricing = await ctx.db
        .query("categoryPricing")
        .withIndex("by_category", (q) => q.eq("category", theater.category!))
        .filter((q) => q.eq(q.field("isActive"), true))
        .unique();
    }

    return {
      ...theater,
      categoryPricing,
    };
  },
});

// Initialize default theaters
export const initializeTheaters = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    // Check if theaters already exist
    const existingTheaters = await ctx.db.query("theaters").collect();
    if (existingTheaters.length > 0) {
      return; // Already initialized
    }

    // Create default theaters
    const defaultTheaters = [
      {
        name: "Theater 1 - Standard",
        capacity: 100,
        category: "Standard",
        features: ["Digital Sound", "Comfortable Seating"],
        isActive: true,
      },
      {
        name: "Theater 2 - Premium",
        capacity: 80,
        category: "Premium",
        features: ["Dolby Atmos", "Reclining Seats", "Premium Sound"],
        isActive: true,
      },
      {
        name: "Theater 3 - IMAX",
        capacity: 120,
        category: "IMAX",
        features: ["IMAX Screen", "IMAX Sound", "Premium Experience"],
        isActive: true,
      },
    ];

    for (const theater of defaultTheaters) {
      await ctx.db.insert("theaters", theater);
    }
  },
});

// Add theater (admin only)
export const addTheater = mutation({
  args: {
    name: v.string(),
    capacity: v.number(),
    category: v.string(),
    features: v.optional(v.array(v.string())),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    return await ctx.db.insert("theaters", {
      ...args,
      isActive: true,
    });
  },
});

// Update theater (admin only)
export const updateTheater = mutation({
  args: {
    theaterId: v.id("theaters"),
    name: v.optional(v.string()),
    capacity: v.optional(v.number()),
    category: v.optional(v.string()),
    features: v.optional(v.array(v.string())),
    isActive: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    const { theaterId, ...updates } = args;
    
    // Remove undefined values
    const cleanUpdates = Object.fromEntries(
      Object.entries(updates).filter(([_, value]) => value !== undefined)
    );

    await ctx.db.patch(theaterId, cleanUpdates);
    return theaterId;
  },
});

// Delete theater (admin only)
export const deleteTheater = mutation({
  args: { theaterId: v.id("theaters") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    await ctx.db.delete(args.theaterId);
  },
});
