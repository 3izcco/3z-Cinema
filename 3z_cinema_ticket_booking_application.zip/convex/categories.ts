// This file is deprecated - categories have been removed from the system
// All functionality has been moved to theaters.ts
