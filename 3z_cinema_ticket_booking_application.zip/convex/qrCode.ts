"use node";

import { action } from "./_generated/server";
import { v } from "convex/values";

// Generate QR code for booking
export const generateQRCode = action({
  args: {
    bookingData: v.object({
      movieName: v.string(),
      theaterName: v.string(),
      category: v.string(),
      finalPrice: v.number(),
      bookingId: v.string(),
      showtime: v.string(),
      seats: v.array(v.string()),
    }),
  },
  handler: async (ctx, args) => {
    // Create QR code data string
    const qrData = JSON.stringify({
      ...args.bookingData,
      timestamp: new Date().toISOString(),
      cinema: "3Z Cinema",
    });

    // For demo purposes, we'll create a simple QR code URL
    // In production, you would use a proper QR code generation library
    const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(qrData)}`;
    
    return {
      qrCodeUrl,
      qrData,
    };
  },
});
