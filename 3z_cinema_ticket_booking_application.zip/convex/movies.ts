import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Get all active movies
export const listActiveMovies = query({
  args: {},
  handler: async (ctx) => {
    const movies = await ctx.db
      .query("movies")
      .withIndex("by_active", (q) => q.eq("isActive", true))
      .collect();

    return Promise.all(
      movies.map(async (movie) => ({
        ...movie,
        posterUrl: movie.posterId ? await ctx.storage.getUrl(movie.posterId) : null,
        baseTicketPrice: movie.baseTicketPrice || movie.ticketPrice || 10, // fallback for legacy data
      }))
    );
  },
});

// Get all movies (admin only)
export const listAllMovies = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    const movies = await ctx.db.query("movies").collect();
    
    return Promise.all(
      movies.map(async (movie) => ({
        ...movie,
        posterUrl: movie.posterId ? await ctx.storage.getUrl(movie.posterId) : null,
        baseTicketPrice: movie.baseTicketPrice || movie.ticketPrice || 10, // fallback for legacy data
      }))
    );
  },
});

// Get movie by ID
export const getMovieById = query({
  args: { movieId: v.id("movies") },
  handler: async (ctx, args) => {
    const movie = await ctx.db.get(args.movieId);
    if (!movie) return null;

    return {
      ...movie,
      posterUrl: movie.posterId ? await ctx.storage.getUrl(movie.posterId) : null,
      baseTicketPrice: movie.baseTicketPrice || movie.ticketPrice || 10, // fallback for legacy data
    };
  },
});

// Add movie (admin only)
export const addMovie = mutation({
  args: {
    title: v.string(),
    description: v.string(),
    duration: v.number(),
    genre: v.string(),
    baseTicketPrice: v.number(),
    rating: v.optional(v.string()),
    director: v.optional(v.string()),
    cast: v.optional(v.array(v.string())),
    posterId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    return await ctx.db.insert("movies", {
      ...args,
      isActive: true,
    });
  },
});

// Update movie (admin only)
export const updateMovie = mutation({
  args: {
    movieId: v.id("movies"),
    title: v.optional(v.string()),
    description: v.optional(v.string()),
    duration: v.optional(v.number()),
    genre: v.optional(v.string()),
    baseTicketPrice: v.optional(v.number()),
    rating: v.optional(v.string()),
    director: v.optional(v.string()),
    cast: v.optional(v.array(v.string())),
    posterId: v.optional(v.id("_storage")),
    isActive: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    const { movieId, ...updates } = args;
    
    // Remove undefined values
    const cleanUpdates = Object.fromEntries(
      Object.entries(updates).filter(([_, value]) => value !== undefined)
    );

    await ctx.db.patch(movieId, cleanUpdates);
    return movieId;
  },
});

// Delete movie (admin only)
export const deleteMovie = mutation({
  args: { movieId: v.id("movies") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    await ctx.db.delete(args.movieId);
  },
});

// Generate upload URL for movie posters
export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    return await ctx.storage.generateUploadUrl();
  },
});

// Initialize default movies with poster URLs
export const initializeMovies = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    // Check if movies already exist
    const existingMovies = await ctx.db.query("movies").collect();
    if (existingMovies.length > 0) {
      return; // Already initialized
    }

    // Create default movies with poster URLs
    const defaultMovies = [
      {
        title: "The Dark Knight",
        description: "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice.",
        duration: 152,
        genre: "Action/Crime",
        baseTicketPrice: 12.99,
        rating: "PG-13",
        director: "Christopher Nolan",
        cast: ["Christian Bale", "Heath Ledger", "Aaron Eckhart", "Michael Caine"],
        posterUrl: "https://images.unsplash.com/photo-1489599735734-79b4fc8c4c8a?w=400&h=600&fit=crop",
        isActive: true,
      },
      {
        title: "Inception",
        description: "A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.",
        duration: 148,
        genre: "Sci-Fi/Thriller",
        baseTicketPrice: 13.99,
        rating: "PG-13",
        director: "Christopher Nolan",
        cast: ["Leonardo DiCaprio", "Marion Cotillard", "Tom Hardy", "Ellen Page"],
        posterUrl: "https://images.unsplash.com/photo-1440404653325-ab127d49abc1?w=400&h=600&fit=crop",
        isActive: true,
      },
      {
        title: "Avengers: Endgame",
        description: "After the devastating events of Avengers: Infinity War, the universe is in ruins. With the help of remaining allies, the Avengers assemble once more.",
        duration: 181,
        genre: "Action/Adventure",
        baseTicketPrice: 14.99,
        rating: "PG-13",
        director: "Anthony Russo, Joe Russo",
        cast: ["Robert Downey Jr.", "Chris Evans", "Mark Ruffalo", "Chris Hemsworth"],
        posterUrl: "https://images.unsplash.com/photo-1518709268805-4e9042af2176?w=400&h=600&fit=crop",
        isActive: true,
      },
      {
        title: "Parasite",
        description: "A poor family schemes to become employed by a wealthy family by infiltrating their household and posing as unrelated, highly qualified individuals.",
        duration: 132,
        genre: "Thriller/Drama",
        baseTicketPrice: 11.99,
        rating: "R",
        director: "Bong Joon-ho",
        cast: ["Song Kang-ho", "Lee Sun-kyun", "Cho Yeo-jeong", "Choi Woo-shik"],
        posterUrl: "https://images.unsplash.com/photo-1574267432553-4b4628081c31?w=400&h=600&fit=crop",
        isActive: true,
      },
      {
        title: "Spider-Man: Into the Spider-Verse",
        description: "Teen Miles Morales becomes the Spider-Man of his universe, and must join with five spider-powered individuals from other dimensions to stop a threat for all realities.",
        duration: 117,
        genre: "Animation/Action",
        baseTicketPrice: 12.49,
        rating: "PG",
        director: "Bob Persichetti, Peter Ramsey, Rodney Rothman",
        cast: ["Shameik Moore", "Jake Johnson", "Hailee Steinfeld", "Mahershala Ali"],
        posterUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=600&fit=crop",
        isActive: true,
      },
      {
        title: "Dune",
        description: "A noble family becomes embroiled in a war for control over the galaxy's most valuable asset while its heir becomes troubled by visions of a dark future.",
        duration: 155,
        genre: "Sci-Fi/Adventure",
        baseTicketPrice: 13.49,
        rating: "PG-13",
        director: "Denis Villeneuve",
        cast: ["Timothée Chalamet", "Rebecca Ferguson", "Oscar Isaac", "Josh Brolin"],
        posterUrl: "https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?w=400&h=600&fit=crop",
        isActive: true,
      },
      {
        title: "Top Gun: Maverick",
        description: "After thirty years, Maverick is still pushing the envelope as a top naval aviator, but must confront ghosts of his past when he leads TOP GUN's elite graduates on a mission that demands the ultimate sacrifice.",
        duration: 130,
        genre: "Action/Drama",
        baseTicketPrice: 13.99,
        rating: "PG-13",
        director: "Joseph Kosinski",
        cast: ["Tom Cruise", "Miles Teller", "Jennifer Connelly", "Jon Hamm"],
        posterUrl: "https://images.unsplash.com/photo-1583608205776-bfd35f0d9f83?w=400&h=600&fit=crop",
        isActive: true,
      },
      {
        title: "Everything Everywhere All at Once",
        description: "A middle-aged Chinese immigrant is swept up into an insane adventure in which she alone can save existence by exploring other universes and connecting with the lives she could have lived.",
        duration: 139,
        genre: "Sci-Fi/Comedy",
        baseTicketPrice: 12.99,
        rating: "R",
        director: "Daniels",
        cast: ["Michelle Yeoh", "Stephanie Hsu", "Ke Huy Quan", "Jamie Lee Curtis"],
        posterUrl: "https://images.unsplash.com/photo-1574375927938-d5a98e8ffe85?w=400&h=600&fit=crop",
        isActive: true,
      },
    ];

    for (const movie of defaultMovies) {
      await ctx.db.insert("movies", movie);
    }
  },
});
