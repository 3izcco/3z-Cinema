import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Get showtimes for a specific movie
export const getMovieShowtimes = query({
  args: { movieId: v.id("movies") },
  handler: async (ctx, args) => {
    const showtimes = await ctx.db
      .query("showtimes")
      .withIndex("by_movie", (q) => q.eq("movieId", args.movieId))
      .filter((q) => q.eq(q.field("isActive"), true))
      .collect();

    return Promise.all(
      showtimes.map(async (showtime) => {
        const theater = await ctx.db.get(showtime.theaterId);
        let categoryPricing = null;
        
        if (theater?.category) {
          categoryPricing = await ctx.db
            .query("categoryPricing")
            .withIndex("by_category", (q) => q.eq("category", theater.category!))
            .filter((q) => q.eq(q.field("isActive"), true))
            .unique();
        }

        return {
          ...showtime,
          theater,
          categoryPricing,
        };
      })
    );
  },
});

// Get all showtimes (admin only)
export const getAllShowtimes = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    const showtimes = await ctx.db.query("showtimes").collect();
    
    return Promise.all(
      showtimes.map(async (showtime) => {
        const movie = await ctx.db.get(showtime.movieId);
        const theater = await ctx.db.get(showtime.theaterId);
        return {
          ...showtime,
          movie,
          theater,
        };
      })
    );
  },
});

// Add showtime (admin only)
export const addShowtime = mutation({
  args: {
    movieId: v.id("movies"),
    theaterId: v.id("theaters"),
    startTime: v.string(),
    endTime: v.string(),
    specialPricing: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    const theater = await ctx.db.get(args.theaterId);
    if (!theater) throw new Error("Theater not found");

    return await ctx.db.insert("showtimes", {
      movieId: args.movieId,
      theaterId: args.theaterId,
      startTime: args.startTime,
      endTime: args.endTime,
      totalSeats: theater.capacity,
      availableSeats: theater.capacity,
      specialPricing: args.specialPricing,
      isActive: true,
    });
  },
});

// Update showtime (admin only)
export const updateShowtime = mutation({
  args: {
    showtimeId: v.id("showtimes"),
    movieId: v.optional(v.id("movies")),
    theaterId: v.optional(v.id("theaters")),
    startTime: v.optional(v.string()),
    endTime: v.optional(v.string()),
    specialPricing: v.optional(v.number()),
    isActive: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    const { showtimeId, ...updates } = args;
    
    // Convert date strings to timestamps
    const cleanUpdates: any = {};
    for (const [key, value] of Object.entries(updates)) {
      if (value !== undefined) {
        cleanUpdates[key] = value;
      }
    }

    // Update theater capacity if theater changed
    if (cleanUpdates.theaterId) {
      const theater = await ctx.db.get(cleanUpdates.theaterId);
      if (theater && 'capacity' in theater) {
        cleanUpdates.totalSeats = theater.capacity;
        // Only update available seats if it's currently equal to total seats (no bookings)
        const currentShowtime = await ctx.db.get(showtimeId);
        if (currentShowtime && currentShowtime.availableSeats === currentShowtime.totalSeats) {
          cleanUpdates.availableSeats = theater.capacity;
        }
      }
    }

    await ctx.db.patch(showtimeId, cleanUpdates);
    return showtimeId;
  },
});

// Initialize showtimes for all movies in all categories
export const initializeShowtimes = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    // Check if showtimes already exist
    const existingShowtimes = await ctx.db.query("showtimes").collect();
    if (existingShowtimes.length > 0) {
      return; // Already initialized
    }

    // Get all active movies and theaters
    const movies = await ctx.db
      .query("movies")
      .filter((q) => q.eq(q.field("isActive"), true))
      .collect();

    const theaters = await ctx.db
      .query("theaters")
      .filter((q) => q.eq(q.field("isActive"), true))
      .collect();

    // Group theaters by category
    const theatersByCategory = theaters.reduce((acc: any, theater) => {
      const category = theater.category || "Standard";
      if (!acc[category]) acc[category] = [];
      acc[category].push(theater);
      return acc;
    }, {});

    // Create showtimes for each movie in each category
    const baseDate = new Date();
    baseDate.setHours(10, 0, 0, 0); // Start at 10 AM today

    for (const movie of movies) {
      let timeOffset = 0;
      
      // Create showtimes for each category
      for (const [category, categoryTheaters] of Object.entries(theatersByCategory)) {
        const theater = (categoryTheaters as any[])[0]; // Use first theater of each category
        
        if (theater) {
          const startTime = new Date(baseDate.getTime() + timeOffset * 60 * 60 * 1000); // Add hours
          const endTime = new Date(startTime.getTime() + (movie.duration + 30) * 60 * 1000); // Movie duration + 30 min buffer

          await ctx.db.insert("showtimes", {
            movieId: movie._id,
            theaterId: theater._id,
            startTime: startTime.toISOString(),
            endTime: endTime.toISOString(),
            totalSeats: theater.capacity,
            availableSeats: theater.capacity,
            isActive: true,
          });

          timeOffset += 4; // 4 hours between different category showtimes for same movie
        }
      }
    }
  },
});
