import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Get user's bookings
export const getUserBookings = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const bookings = await ctx.db
      .query("bookings")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .collect();

    return Promise.all(
      bookings.map(async (booking) => {
        const movie = await ctx.db.get(booking.movieId);
        const showtime = await ctx.db.get(booking.showtimeId);
        const theater = await ctx.db.get(booking.theaterId);
        return {
          ...booking,
          movie,
          showtime,
          theater,
        };
      })
    );
  },
});

// Get all bookings (admin only)
export const getAllBookings = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    const bookings = await ctx.db.query("bookings").collect();
    
    return Promise.all(
      bookings.map(async (booking) => {
        const movie = await ctx.db.get(booking.movieId);
        const showtime = await ctx.db.get(booking.showtimeId);
        const theater = await ctx.db.get(booking.theaterId);
        const user = booking.userId ? await ctx.db.get(booking.userId) : null;
        return {
          ...booking,
          movie,
          showtime,
          theater,
          user,
        };
      })
    );
  },
});

// Get occupied seats for a showtime
export const getOccupiedSeats = query({
  args: { showtimeId: v.id("showtimes") },
  handler: async (ctx, args) => {
    const bookings = await ctx.db
      .query("bookings")
      .withIndex("by_showtime", (q) => q.eq("showtimeId", args.showtimeId))
      .filter((q) => q.eq(q.field("paymentStatus"), "completed"))
      .collect();

    const occupiedSeats = new Set<string>();
    bookings.forEach((booking) => {
      booking.seats.forEach((seat) => occupiedSeats.add(seat));
    });

    return Array.from(occupiedSeats);
  },
});

// Create booking (requires authentication)
export const createBooking = mutation({
  args: {
    movieId: v.id("movies"),
    showtimeId: v.id("showtimes"),
    theaterId: v.id("theaters"),
    seats: v.array(v.string()),
    paymentMethod: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Authentication required to create booking");
    }

    // Get movie, showtime, and theater details
    const movie = await ctx.db.get(args.movieId);
    const showtime = await ctx.db.get(args.showtimeId);
    const theater = await ctx.db.get(args.theaterId);
    
    if (!movie || !showtime || !theater) {
      throw new Error("Movie, showtime, or theater not found");
    }

    // Get category pricing
    let categoryPricing = null;
    if (theater.category) {
      categoryPricing = await ctx.db
        .query("categoryPricing")
        .withIndex("by_category", (q) => q.eq("category", theater.category!))
        .filter((q) => q.eq(q.field("isActive"), true))
        .unique();
    }

    // Calculate pricing
    const basePrice = showtime.specialPricing || movie.baseTicketPrice || movie.ticketPrice || 10;
    const categoryPrice = categoryPricing?.extraPrice || 0;
    const pricePerTicket = basePrice + categoryPrice;
    const totalAmount = pricePerTicket * args.seats.length;

    // Generate booking reference
    const bookingReference = `3Z${Date.now()}${Math.random().toString(36).substr(2, 4).toUpperCase()}`;

    // Prepare QR code data
    const qrCodeData = {
      movieName: movie.title,
      theaterName: theater.name,
      category: theater.category || "Standard",
      finalPrice: totalAmount,
      bookingId: bookingReference,
      showtime: new Date(showtime.startTime).toISOString(),
      seats: args.seats,
    };

    // Create booking
    const bookingId = await ctx.db.insert("bookings", {
      userId,
      movieId: args.movieId,
      showtimeId: args.showtimeId,
      theaterId: args.theaterId,
      seats: args.seats,
      basePrice,
      categoryPrice,
      totalAmount,
      paymentMethod: args.paymentMethod,
      paymentStatus: "completed", // Simplified for demo
      bookingReference,
      qrCodeData,
      isAnonymous: false,
    });

    // Generate QR code URL (simplified for demo)
    const qrData = JSON.stringify(qrCodeData);
    const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(qrData)}`;
    
    // Update booking with QR code
    await ctx.db.patch(bookingId, {
      qrCode: qrCodeUrl,
    });

    // Update available seats
    await ctx.db.patch(args.showtimeId, {
      availableSeats: showtime.availableSeats - args.seats.length,
    });

    return { 
      bookingId, 
      bookingReference,
      totalAmount,
      basePrice,
      categoryPrice,
      priceBreakdown: {
        basePrice: basePrice * args.seats.length,
        categoryExtra: categoryPrice * args.seats.length,
        total: totalAmount,
      }
    };
  },
});

// Get booking by reference (public - no auth required)
export const getBookingByReference = query({
  args: { reference: v.string() },
  handler: async (ctx, args) => {
    const booking = await ctx.db
      .query("bookings")
      .withIndex("by_reference", (q) => q.eq("bookingReference", args.reference))
      .unique();

    if (!booking) return null;

    const movie = await ctx.db.get(booking.movieId);
    const showtime = await ctx.db.get(booking.showtimeId);
    const theater = await ctx.db.get(booking.theaterId);
    
    return {
      ...booking,
      movie,
      showtime,
      theater,
    };
  },
});

// Delete all bookings (admin only)
export const deleteAllBookings = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const userProfile = await ctx.db
      .query("userProfiles")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .unique();

    if (!userProfile || userProfile.role !== "admin") {
      throw new Error("Admin access required");
    }

    // Get all bookings
    const bookings = await ctx.db.query("bookings").collect();
    
    // Delete all bookings
    for (const booking of bookings) {
      await ctx.db.delete(booking._id);
    }

    // Reset available seats for all showtimes
    const showtimes = await ctx.db.query("showtimes").collect();
    for (const showtime of showtimes) {
      await ctx.db.patch(showtime._id, {
        availableSeats: showtime.totalSeats,
      });
    }

    return { deletedCount: bookings.length };
  },
});
