import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { RoleSelection } from "./components/RoleSelection";
import { AdminDashboard } from "./components/AdminDashboard";
import { CustomerDashboard } from "./components/CustomerDashboard";

import { useState } from "react";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm h-16 flex justify-between items-center border-b shadow-sm px-4">
        <h2 className="text-2xl font-bold text-blue-600">3z Cinema</h2>
        <div className="flex items-center gap-4">
          <Authenticated>
            <SignOutButton />
          </Authenticated>
        </div>
      </header>
      <main className="flex-1 p-4">
        <Content />
      </main>
      <Toaster />
    </div>
  );
}

function Content() {
  const userProfile = useQuery(api.users.getCurrentUserProfile);
  const [selectedRole, setSelectedRole] = useState<string | null>(null);

  if (userProfile === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto">
      <Unauthenticated>
        <div className="max-w-md mx-auto mt-20">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Welcome to 3z Cinema</h1>
            <p className="text-lg text-gray-600">Book your movie tickets with ease</p>
          </div>
          {!selectedRole ? (
            <RoleSelection onRoleSelect={setSelectedRole} />
          ) : (
            <div>
              <button
                onClick={() => setSelectedRole(null)}
                className="mb-4 text-blue-600 hover:text-blue-800 flex items-center gap-2"
              >
                ← Back to role selection
              </button>
              <SignInForm />
            </div>
          )}
        </div>
      </Unauthenticated>

      <Authenticated>
        {!userProfile?.profile ? (
          <div className="max-w-md mx-auto mt-20">
            <RoleSelection onRoleSelect={() => {}} isProfileSetup={true} />
          </div>
        ) : userProfile.profile.role === "admin" ? (
          <AdminDashboard />
        ) : (
          <CustomerDashboard />
        )}
      </Authenticated>
    </div>
  );
}
