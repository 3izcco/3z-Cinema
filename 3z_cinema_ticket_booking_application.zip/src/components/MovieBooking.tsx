import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState } from "react";

interface MovieBookingProps {
  movie: any;
  onBack: () => void;
}

export function MovieBooking({ movie, onBack }: MovieBookingProps) {
  const showtimes = useQuery(api.showtimes.getMovieShowtimes, { movieId: movie._id });
  const createBooking = useMutation(api.bookings.createBooking);
  const [selectedShowtime, setSelectedShowtime] = useState<any>(null);
  const getOccupiedSeats = useQuery(
    api.bookings.getOccupiedSeats,
    selectedShowtime ? { showtimeId: selectedShowtime._id } : "skip"
  );
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const [isBooking, setIsBooking] = useState(false);
  const [bookingComplete, setBookingComplete] = useState<any>(null);
  const [selectedPaymentMethod, setSelectedPaymentMethod] = useState<string>("credit_card");

  if (showtimes === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const handleBooking = async () => {
    if (!selectedShowtime || selectedSeats.length === 0) return;

    setIsBooking(true);
    try {
      const result = await createBooking({
        movieId: movie._id,
        showtimeId: selectedShowtime._id,
        theaterId: selectedShowtime.theaterId,
        seats: selectedSeats,
        paymentMethod: selectedPaymentMethod,
      });

      setBookingComplete(result);
    } catch (error) {
      console.error("Booking failed:", error);
      alert("Booking failed. Please try again.");
    } finally {
      setIsBooking(false);
    }
  };

  if (bookingComplete) {
    return <BookingConfirmation booking={bookingComplete} movie={movie} showtime={selectedShowtime} onBack={onBack} />;
  }

  if (selectedShowtime) {
    return (
      <SeatSelection
        movie={movie}
        showtime={selectedShowtime}
        occupiedSeats={getOccupiedSeats || []}
        selectedSeats={selectedSeats}
        onSeatsChange={setSelectedSeats}
        onBack={() => setSelectedShowtime(null)}
        onBooking={handleBooking}
        isBooking={isBooking}
        selectedPaymentMethod={selectedPaymentMethod}
        onPaymentMethodChange={setSelectedPaymentMethod}
      />
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <button
          onClick={onBack}
          className="mb-4 text-blue-600 hover:text-blue-800 flex items-center gap-2"
        >
          ← Back to Movies
        </button>
        
        <div className="flex gap-6">
          {movie.posterUrl && (
            <img
              src={movie.posterUrl}
              alt={movie.title}
              className="w-32 h-48 object-cover rounded-lg"
            />
          )}
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">{movie.title}</h1>
            <p className="text-gray-600 mb-2">{movie.genre} • {movie.duration} minutes</p>
            {movie.rating && (
              <p className="text-gray-600 mb-2">Rated: {movie.rating}</p>
            )}
            {movie.director && (
              <p className="text-gray-600 mb-2">Director: {movie.director}</p>
            )}
            {movie.cast && movie.cast.length > 0 && (
              <p className="text-gray-600 mb-4">Cast: {movie.cast.join(", ")}</p>
            )}
            <p className="text-gray-700 mb-4">{movie.description}</p>
            <p className="text-2xl font-bold text-green-600">From ${movie.baseTicketPrice} per ticket <span className="text-sm text-gray-500">(+ category charges)</span></p>
          </div>
        </div>
      </div>

      {/* Showtimes */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Select Showtime</h2>
        
        {showtimes.length === 0 ? (
          <p className="text-gray-600">No showtimes available for this movie.</p>
        ) : (
          <div className="space-y-4">
            {/* Group showtimes by theater category */}
            {Object.entries(
              showtimes.reduce((acc: any, showtime) => {
                const categoryName = showtime.theater?.category || "Standard";
                if (!acc[categoryName]) acc[categoryName] = [];
                acc[categoryName].push(showtime);
                return acc;
              }, {})
            ).map(([categoryName, categoryShowtimes]: [string, any]) => {
              const categoryPricing = (categoryShowtimes as any[])[0]?.categoryPricing;
              const extraPrice = categoryPricing?.extraPrice || 0;
              
              return (
                <div key={categoryName} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex justify-between items-center mb-3">
                    <div>
                      <h3 className="font-semibold text-gray-900">{categoryName} Theaters</h3>
                      {categoryPricing?.description && (
                        <p className="text-sm text-gray-600">{categoryPricing.description}</p>
                      )}
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-green-600">
                        ${(movie.baseTicketPrice + extraPrice).toFixed(2)}
                      </div>
                      <div className="text-xs text-gray-500">
                        Base: ${movie.baseTicketPrice} + Category: ${extraPrice.toFixed(2)}
                      </div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {(categoryShowtimes as any[]).map((showtime) => {
                      const startTime = new Date(showtime.startTime);
                      const finalPrice = showtime.specialPricing || (movie.baseTicketPrice + extraPrice);
                      
                      return (
                        <button
                          key={showtime._id}
                          onClick={() => setSelectedShowtime(showtime)}
                          className="p-3 border border-gray-200 rounded-lg bg-gray-50 hover:bg-blue-50 hover:border-blue-300 transition-colors text-left"
                        >
                          <div className="font-medium text-gray-900">
                            {startTime.toLocaleDateString()}
                          </div>
                          <div className="text-lg font-semibold text-blue-600">
                            {startTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </div>
                          <div className="text-sm text-gray-600">
                            {showtime.theater?.name}
                          </div>
                          <div className="text-sm text-gray-600">
                            {showtime.availableSeats} seats available
                          </div>
                          <div className="text-lg font-bold text-green-600 mt-2">
                            ${finalPrice.toFixed(2)}
                          </div>
                          {showtime.specialPricing && (
                            <div className="text-xs text-orange-600">Special Pricing</div>
                          )}
                        </button>
                      );
                    })}
                  </div>
                  
                  {/* Category features */}
                  {(categoryShowtimes as any[])[0]?.theater?.features && (
                    <div className="mt-3">
                      <p className="text-xs font-medium text-gray-700">Features:</p>
                      <div className="flex flex-wrap gap-2 mt-1">
                        {(categoryShowtimes as any[])[0].theater.features.map((feature: string, index: number) => (
                          <span key={index} className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                            {feature}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function SeatSelection({
  movie,
  showtime,
  occupiedSeats,
  selectedSeats,
  onSeatsChange,
  onBack,
  onBooking,
  isBooking,
  selectedPaymentMethod,
  onPaymentMethodChange,
}: {
  movie: any;
  showtime: any;
  occupiedSeats: string[];
  selectedSeats: string[];
  onSeatsChange: (seats: string[]) => void;
  onBack: () => void;
  onBooking: () => void;
  isBooking: boolean;
  selectedPaymentMethod: string;
  onPaymentMethodChange: (method: string) => void;
}) {
  const rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];
  const seatsPerRow = 12;

  const paymentMethods = [
    { id: 'credit_card', name: 'Credit Card', icon: '💳' },
    { id: 'debit_card', name: 'Debit Card', icon: '💳' },
    { id: 'apple_pay', name: 'Apple Pay', icon: '🍎' },
    { id: 'google_pay', name: 'Google Pay', icon: '🔍' },
    { id: 'samsung_pay', name: 'Samsung Pay', icon: '📱' },
    { id: 'paypal', name: 'PayPal', icon: '🅿️' },
    { id: 'venmo', name: 'Venmo', icon: '💙' },
    { id: 'cash_app', name: 'Cash App', icon: '💚' },
    { id: 'zelle', name: 'Zelle', icon: '⚡' },
    { id: 'bank_transfer', name: 'Bank Transfer', icon: '🏦' },
  ];

  const toggleSeat = (seatId: string) => {
    if (occupiedSeats.includes(seatId)) return;
    
    if (selectedSeats.includes(seatId)) {
      onSeatsChange(selectedSeats.filter(seat => seat !== seatId));
    } else {
      onSeatsChange([...selectedSeats, seatId]);
    }
  };

  const getSeatStatus = (seatId: string) => {
    if (occupiedSeats.includes(seatId)) return 'occupied';
    if (selectedSeats.includes(seatId)) return 'selected';
    return 'available';
  };

  const getSeatClass = (status: string) => {
    switch (status) {
      case 'occupied':
        return 'bg-red-500 text-white cursor-not-allowed';
      case 'selected':
        return 'bg-blue-500 text-white cursor-pointer';
      case 'available':
        return 'bg-gray-200 hover:bg-gray-300 cursor-pointer';
      default:
        return 'bg-gray-200';
    }
  };

  // Calculate pricing
  const basePrice = movie.baseTicketPrice;
  const categoryPrice = showtime.categoryPricing?.extraPrice || 0;
  const pricePerTicket = showtime.specialPricing || (basePrice + categoryPrice);
  const totalPrice = pricePerTicket * selectedSeats.length;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <button
          onClick={onBack}
          className="mb-4 text-blue-600 hover:text-blue-800 flex items-center gap-2"
        >
          ← Back to Showtimes
        </button>
        
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">{movie.title}</h1>
            <p className="text-gray-600">
              {new Date(showtime.startTime).toLocaleDateString()} at{' '}
              {new Date(showtime.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </p>
            <p className="text-gray-600">{showtime.theater?.name} - {showtime.theater?.category}</p>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-green-600">${pricePerTicket.toFixed(2)}</div>
            <div className="text-sm text-gray-500">per ticket</div>
            {showtime.specialPricing ? (
              <div className="text-xs text-orange-600">Special Pricing</div>
            ) : (
              <div className="text-xs text-gray-500">
                Base: ${basePrice} + Category: ${categoryPrice.toFixed(2)}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Seat Map */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Select Your Seats</h2>
        
        {/* Screen */}
        <div className="mb-8">
          <div className="w-full h-4 bg-gray-800 rounded-t-full mb-2"></div>
          <p className="text-center text-sm text-gray-600">SCREEN</p>
        </div>

        {/* Seat Grid */}
        <div className="space-y-2 mb-6">
          {rows.map((row) => (
            <div key={row} className="flex items-center justify-center gap-1">
              <div className="w-8 text-center font-medium text-gray-600">{row}</div>
              {Array.from({ length: seatsPerRow }, (_, i) => {
                const seatNumber = i + 1;
                const seatId = `${row}${seatNumber}`;
                const status = getSeatStatus(seatId);
                
                return (
                  <button
                    key={seatId}
                    onClick={() => toggleSeat(seatId)}
                    disabled={status === 'occupied'}
                    className={`w-8 h-8 text-xs font-medium rounded ${getSeatClass(status)}`}
                  >
                    {seatNumber}
                  </button>
                );
              })}
            </div>
          ))}
        </div>

        {/* Legend */}
        <div className="flex justify-center gap-6 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-gray-200 rounded"></div>
            <span>Available</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-blue-500 rounded"></div>
            <span>Selected</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-red-500 rounded"></div>
            <span>Occupied</span>
          </div>
        </div>
      </div>

      {/* Payment Method Selection */}
      {selectedSeats.length > 0 && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Select Payment Method</h3>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 mb-6">
            {paymentMethods.map((method) => (
              <button
                key={method.id}
                onClick={() => onPaymentMethodChange(method.id)}
                className={`p-3 border rounded-lg text-center transition-colors ${
                  selectedPaymentMethod === method.id
                    ? 'border-blue-500 bg-blue-50 text-blue-700'
                    : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                }`}
              >
                <div className="text-2xl mb-1">{method.icon}</div>
                <div className="text-xs font-medium">{method.name}</div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Booking Summary */}
      {selectedSeats.length > 0 && (
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Booking Summary</h3>
          
          <div className="space-y-3">
            <div className="flex justify-between">
              <span>Selected Seats:</span>
              <span className="font-medium">{selectedSeats.join(', ')}</span>
            </div>
            <div className="flex justify-between">
              <span>Number of Tickets:</span>
              <span className="font-medium">{selectedSeats.length}</span>
            </div>
            <div className="flex justify-between">
              <span>Price per Ticket:</span>
              <span className="font-medium">${pricePerTicket.toFixed(2)}</span>
            </div>
            {!showtime.specialPricing && (
              <div className="text-sm text-gray-600 space-y-1">
                <div className="flex justify-between">
                  <span className="ml-4">Base Price:</span>
                  <span>${basePrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="ml-4">{showtime.theater?.category} Extra:</span>
                  <span>+${categoryPrice.toFixed(2)}</span>
                </div>
              </div>
            )}
            <div className="flex justify-between">
              <span>Payment Method:</span>
              <span className="font-medium">
                {paymentMethods.find(m => m.id === selectedPaymentMethod)?.name}
              </span>
            </div>
            <hr />
            <div className="flex justify-between text-lg font-bold">
              <span>Total Amount:</span>
              <span className="text-green-600">${totalPrice.toFixed(2)}</span>
            </div>
          </div>

          <button
            onClick={onBooking}
            disabled={isBooking}
            className="w-full mt-6 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 font-semibold"
          >
            {isBooking ? "Processing Payment..." : `Pay with ${paymentMethods.find(m => m.id === selectedPaymentMethod)?.name} - $${totalPrice.toFixed(2)}`}
          </button>
        </div>
      )}
    </div>
  );
}

function BookingConfirmation({ 
  booking, 
  movie, 
  showtime, 
  onBack 
}: { 
  booking: any; 
  movie: any; 
  showtime: any; 
  onBack: () => void; 
}) {
  const bookingDetails = useQuery(api.bookings.getBookingByReference, { 
    reference: booking.bookingReference 
  });

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="bg-green-50 border border-green-200 rounded-lg p-6 text-center">
        <div className="text-6xl mb-4">🎉</div>
        <h1 className="text-3xl font-bold text-green-800 mb-2">Booking Confirmed!</h1>
        <p className="text-green-700">Your tickets have been successfully booked.</p>
      </div>

      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Booking Details</h2>
        
        <div className="space-y-3">
          <div className="flex justify-between">
            <span className="text-gray-600">Booking Reference:</span>
            <span className="font-mono font-bold text-lg">{booking.bookingReference}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Movie:</span>
            <span className="font-medium">{movie.title}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Theater:</span>
            <span className="font-medium">{showtime.theater?.name} - {showtime.theater?.category}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Date & Time:</span>
            <span className="font-medium">
              {new Date(showtime.startTime).toLocaleDateString()} at{' '}
              {new Date(showtime.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Total Amount:</span>
            <span className="font-bold text-green-600 text-lg">${booking.totalAmount.toFixed(2)}</span>
          </div>
          
          {booking.priceBreakdown && (
            <div className="mt-4 p-3 bg-gray-50 rounded">
              <h4 className="font-medium text-gray-900 mb-2">Price Breakdown:</h4>
              <div className="text-sm space-y-1">
                <div className="flex justify-between">
                  <span>Base Price ({booking.priceBreakdown.total / booking.totalAmount} tickets):</span>
                  <span>${booking.priceBreakdown.basePrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>{showtime.theater?.category} Category Extra:</span>
                  <span>+${booking.priceBreakdown.categoryExtra.toFixed(2)}</span>
                </div>
                <hr className="my-1" />
                <div className="flex justify-between font-medium">
                  <span>Total:</span>
                  <span>${booking.priceBreakdown.total.toFixed(2)}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* QR Code */}
      {bookingDetails?.qrCode && (
        <div className="bg-white rounded-lg shadow-md p-6 text-center">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Your QR Code</h3>
          <img 
            src={bookingDetails.qrCode} 
            alt="Booking QR Code" 
            className="mx-auto mb-4 border rounded"
          />
          <p className="text-sm text-gray-600">
            Show this QR code at the cinema for entry verification
          </p>
        </div>
      )}

      <div className="bg-blue-50 rounded-lg p-6">
        <h3 className="font-semibold text-blue-900 mb-2">Important Information</h3>
        <ul className="text-sm text-blue-800 space-y-1">
          <li>• Please arrive at least 15 minutes before showtime</li>
          <li>• Bring a valid ID for verification</li>
          <li>• Show your QR code at the entrance</li>
          <li>• Keep your booking reference for any inquiries</li>
        </ul>
      </div>

      <div className="text-center">
        <button
          onClick={onBack}
          className="px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
        >
          Back to Movies
        </button>
      </div>
    </div>
  );
}
