// This component is no longer needed as anonymous access has been removed.
// All users must be authenticated to access the system.

export function AnonymousBrowsing() {
  return null;
}
