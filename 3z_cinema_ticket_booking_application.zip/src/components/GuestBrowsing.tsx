import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState } from "react";

interface GuestBrowsingProps {
  onSignInClick: () => void;
}

export function GuestBrowsing({ onSignInClick }: GuestBrowsingProps) {
  const movies = useQuery(api.movies.listActiveMovies);
  const [selectedMovie, setSelectedMovie] = useState<any>(null);

  if (movies === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (selectedMovie) {
    // Redirect to sign in when a movie is selected
    onSignInClick();
    return null;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome to 3Z Cinema</h1>
            <p className="text-gray-600">Sign in or create an account to book tickets!</p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={onSignInClick}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Sign In
            </button>
            <button
              onClick={onSignInClick}
              className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
            >
              Create Account
            </button>
          </div>
        </div>
      </div>

      {/* Movies Grid */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Now Showing</h2>
        
        {movies.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">🎬</div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">No movies available</h3>
            <p className="text-gray-600">Check back later for new releases!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {movies.map((movie) => (
              <MovieCard 
                key={movie._id} 
                movie={movie} 
                onSelect={() => setSelectedMovie(movie)}
                onSignInClick={onSignInClick}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function MovieCard({ 
  movie, 
  onSelect, 
  onSignInClick 
}: { 
  movie: any; 
  onSelect: () => void;
  onSignInClick: () => void;
}) {
  return (
    <div className="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow">
      <div className="cursor-pointer" onClick={onSelect}>
        {movie.posterUrl ? (
          <img
            src={movie.posterUrl}
            alt={movie.title}
            className="w-full h-64 object-cover"
          />
        ) : (
          <div className="w-full h-64 bg-gray-200 flex items-center justify-center">
            <span className="text-4xl">🎬</span>
          </div>
        )}
        <div className="p-4">
          <h3 className="font-semibold text-gray-900 mb-2">{movie.title}</h3>
          <p className="text-sm text-gray-600 mb-2">{movie.genre} • {movie.duration} min</p>
          {movie.rating && (
            <p className="text-sm text-gray-600 mb-2">Rated: {movie.rating}</p>
          )}
          <p className="text-sm text-gray-600 mb-3 line-clamp-2">{movie.description}</p>
          <div className="flex justify-between items-center">
            <span className="text-lg font-bold text-green-600">From ${movie.baseTicketPrice}</span>
            <div className="flex gap-2">
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  onSignInClick();
                }}
                className="px-3 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700"
              >
                Sign In to Book
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
