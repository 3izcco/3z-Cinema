import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState } from "react";

export function AdminDashboard() {
  const movies = useQuery(api.movies.listAllMovies);
  const theaters = useQuery(api.theaters.listAllTheaters);
  const showtimes = useQuery(api.showtimes.getAllShowtimes);
  const bookings = useQuery(api.bookings.getAllBookings);
  const categoryPricing = useQuery(api.categoryPricing.getAllCategoryPricing);
  
  const addMovie = useMutation(api.movies.addMovie);
  const updateMovie = useMutation(api.movies.updateMovie);
  const deleteMovie = useMutation(api.movies.deleteMovie);
  const addTheater = useMutation(api.theaters.addTheater);
  const updateTheater = useMutation(api.theaters.updateTheater);
  const addShowtime = useMutation(api.showtimes.addShowtime);
  const updateShowtime = useMutation(api.showtimes.updateShowtime);
  const initializeTheaters = useMutation(api.theaters.initializeTheaters);
  const initializeMovies = useMutation(api.movies.initializeMovies);
  const initializeCategoryPricing = useMutation(api.categoryPricing.initializeCategoryPricing);
  const initializeShowtimes = useMutation(api.showtimes.initializeShowtimes);
  const deleteAllBookings = useMutation(api.bookings.deleteAllBookings);
  
  const [activeTab, setActiveTab] = useState("overview");
  const [showAddMovie, setShowAddMovie] = useState(false);
  const [showAddTheater, setShowAddTheater] = useState(false);
  const [showAddShowtime, setShowAddShowtime] = useState(false);
  const [editingMovie, setEditingMovie] = useState<any>(null);
  const [editingTheater, setEditingTheater] = useState<any>(null);
  const [editingShowtime, setEditingShowtime] = useState<any>(null);

  const handleInitializeData = async () => {
    try {
      await initializeTheaters();
      await initializeMovies();
      await initializeCategoryPricing();
      await initializeShowtimes();
      alert("Default data initialized successfully!");
    } catch (error) {
      console.error("Failed to initialize data:", error);
      alert("Failed to initialize data. Please try again.");
    }
  };

  const handleDeleteAllBookings = async () => {
    if (confirm("Are you sure you want to delete ALL bookings? This action cannot be undone.")) {
      try {
        const result = await deleteAllBookings();
        alert(`Successfully deleted ${result.deletedCount} bookings and reset seat availability.`);
      } catch (error) {
        console.error("Failed to delete bookings:", error);
        alert("Failed to delete bookings. Please try again.");
      }
    }
  };

  if (movies === undefined || theaters === undefined || showtimes === undefined || bookings === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const totalRevenue = bookings.reduce((sum, booking) => sum + booking.totalAmount, 0);
  const totalBookings = bookings.length;
  const activeMovies = movies.filter(movie => movie.isActive).length;
  const activeTheaters = theaters.filter(theater => theater.isActive).length;

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Admin Dashboard</h1>
            <p className="text-gray-600">Manage your cinema system</p>
          </div>
          <div className="flex gap-3">
            <button
              onClick={handleInitializeData}
              className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700"
            >
              Initialize Default Data
            </button>
            <button
              onClick={handleDeleteAllBookings}
              className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
            >
              Delete All Bookings
            </button>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="text-3xl mr-4">💰</div>
            <div>
              <p className="text-sm font-medium text-gray-600">Total Revenue</p>
              <p className="text-2xl font-bold text-green-600">${totalRevenue.toFixed(2)}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="text-3xl mr-4">🎫</div>
            <div>
              <p className="text-sm font-medium text-gray-600">Total Bookings</p>
              <p className="text-2xl font-bold text-blue-600">{totalBookings}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="text-3xl mr-4">🎬</div>
            <div>
              <p className="text-sm font-medium text-gray-600">Active Movies</p>
              <p className="text-2xl font-bold text-purple-600">{activeMovies}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center">
            <div className="text-3xl mr-4">🏛️</div>
            <div>
              <p className="text-sm font-medium text-gray-600">Active Theaters</p>
              <p className="text-2xl font-bold text-orange-600">{activeTheaters}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white rounded-lg shadow-md">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {[
              { id: "overview", label: "Overview", icon: "📊" },
              { id: "movies", label: "Movies", icon: "🎬" },
              { id: "theaters", label: "Theaters", icon: "🏛️" },
              { id: "showtimes", label: "Showtimes", icon: "⏰" },
              { id: "bookings", label: "Bookings", icon: "🎫" },
              { id: "pricing", label: "Pricing", icon: "💰" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? "border-blue-500 text-blue-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                <span className="mr-2">{tab.icon}</span>
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === "overview" && (
            <OverviewTab 
              bookings={bookings} 
              movies={movies} 
              theaters={theaters} 
              showtimes={showtimes}
            />
          )}
          {activeTab === "movies" && (
            <MoviesTab 
              movies={movies}
              onAddMovie={() => setShowAddMovie(true)}
              onEditMovie={setEditingMovie}
              onDeleteMovie={deleteMovie}
            />
          )}
          {activeTab === "theaters" && (
            <TheatersTab 
              theaters={theaters}
              onAddTheater={() => setShowAddTheater(true)}
              onEditTheater={setEditingTheater}
            />
          )}
          {activeTab === "showtimes" && (
            <ShowtimesTab 
              showtimes={showtimes}
              movies={movies}
              theaters={theaters}
              onAddShowtime={() => setShowAddShowtime(true)}
              onEditShowtime={setEditingShowtime}
            />
          )}
          {activeTab === "bookings" && (
            <BookingsTab bookings={bookings} onDeleteAllBookings={handleDeleteAllBookings} />
          )}
          {activeTab === "pricing" && (
            <PricingTab categoryPricing={categoryPricing} />
          )}
        </div>
      </div>

      {/* Modals */}
      {showAddMovie && (
        <AddMovieModal 
          onClose={() => setShowAddMovie(false)}
          onAdd={addMovie}
        />
      )}
      
      {editingMovie && (
        <EditMovieModal 
          movie={editingMovie}
          onClose={() => setEditingMovie(null)}
          onUpdate={updateMovie}
        />
      )}

      {showAddTheater && (
        <AddTheaterModal 
          onClose={() => setShowAddTheater(false)}
          onAdd={addTheater}
          categoryPricing={categoryPricing}
        />
      )}
      
      {editingTheater && (
        <EditTheaterModal 
          theater={editingTheater}
          onClose={() => setEditingTheater(null)}
          onUpdate={updateTheater}
          categoryPricing={categoryPricing}
        />
      )}

      {showAddShowtime && (
        <AddShowtimeModal 
          onClose={() => setShowAddShowtime(false)}
          onAdd={addShowtime}
          movies={movies}
          theaters={theaters}
        />
      )}
      
      {editingShowtime && (
        <EditShowtimeModal 
          showtime={editingShowtime}
          onClose={() => setEditingShowtime(null)}
          onUpdate={updateShowtime}
          movies={movies}
          theaters={theaters}
        />
      )}
    </div>
  );
}

// Overview Tab Component
function OverviewTab({ bookings, movies, theaters, showtimes }: any) {
  const recentBookings = bookings.slice(-5).reverse();
  
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Bookings</h3>
        {recentBookings.length === 0 ? (
          <p className="text-gray-600">No bookings yet.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Reference
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Movie
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Customer
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Amount
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {recentBookings.map((booking: any) => (
                  <tr key={booking._id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {booking.bookingReference}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {booking.movie?.title || "Unknown"}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {booking.user?.name || "User"}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      ${booking.totalAmount.toFixed(2)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        booking.paymentStatus === 'completed' 
                          ? 'bg-green-100 text-green-800'
                          : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {booking.paymentStatus}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

// Movies Tab Component
function MoviesTab({ movies, onAddMovie, onEditMovie, onDeleteMovie }: any) {
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold text-gray-900">Movies Management</h3>
        <button
          onClick={onAddMovie}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          Add Movie
        </button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Title
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Genre
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Duration
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Base Price
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {movies.map((movie: any) => (
              <tr key={movie._id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {movie.title}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {movie.genre}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {movie.duration} min
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  ${movie.baseTicketPrice || movie.ticketPrice || 0}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                    movie.isActive 
                      ? 'bg-green-100 text-green-800'
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {movie.isActive ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                  <button
                    onClick={() => onEditMovie(movie)}
                    className="text-blue-600 hover:text-blue-900"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => {
                      if (confirm(`Are you sure you want to delete "${movie.title}"?`)) {
                        onDeleteMovie({ movieId: movie._id });
                      }
                    }}
                    className="text-red-600 hover:text-red-900"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// Theaters Tab Component
function TheatersTab({ theaters, onAddTheater, onEditTheater }: any) {
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold text-gray-900">Theaters Management</h3>
        <button
          onClick={onAddTheater}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          Add Theater
        </button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Name
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Category
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Capacity
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Features
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {theaters.map((theater: any) => (
              <tr key={theater._id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {theater.name}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {theater.category || "Standard"}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {theater.capacity}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {theater.features?.join(", ") || "None"}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                    theater.isActive 
                      ? 'bg-green-100 text-green-800'
                      : 'bg-red-100 text-red-800'
                  }`}>
                    {theater.isActive ? 'Active' : 'Inactive'}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <button
                    onClick={() => onEditTheater(theater)}
                    className="text-blue-600 hover:text-blue-900"
                  >
                    Edit
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// Showtimes Tab Component
function ShowtimesTab({ showtimes, movies, theaters, onAddShowtime, onEditShowtime }: any) {
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold text-gray-900">Showtimes Management</h3>
        <button
          onClick={onAddShowtime}
          className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
        >
          Add Showtime
        </button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Movie
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Theater
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Start Time
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Available Seats
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Special Price
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {showtimes.map((showtime: any) => (
              <tr key={showtime._id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {showtime.movie?.title || "Unknown"}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {showtime.theater?.name || "Unknown"} ({showtime.theater?.category || "Standard"})
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {new Date(showtime.startTime).toLocaleString()}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {showtime.availableSeats} / {showtime.totalSeats}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {showtime.specialPricing ? `$${showtime.specialPricing}` : "None"}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <button
                    onClick={() => onEditShowtime(showtime)}
                    className="text-blue-600 hover:text-blue-900"
                  >
                    Edit
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// Bookings Tab Component
function BookingsTab({ bookings, onDeleteAllBookings }: any) {
  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold text-gray-900">All Bookings</h3>
        <button
          onClick={onDeleteAllBookings}
          className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
        >
          Delete All Bookings
        </button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Reference
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Movie
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Customer
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Theater
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Seats
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Amount
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Date
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {bookings.map((booking: any) => (
              <tr key={booking._id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  {booking.bookingReference}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {booking.movie?.title || "Unknown"}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {booking.user?.name || "User"}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {booking.theater?.name || "Unknown"} ({booking.theater?.category || "Standard"})
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {booking.seats.join(", ")}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  ${booking.totalAmount.toFixed(2)}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                  {new Date(booking._creationTime).toLocaleDateString()}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// Pricing Tab Component
function PricingTab({ categoryPricing }: any) {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-gray-900">Category Pricing</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categoryPricing?.map((pricing: any) => (
          <div key={pricing._id} className="bg-gray-50 rounded-lg p-6">
            <h4 className="text-lg font-semibold text-gray-900 mb-2">{pricing.category}</h4>
            <p className="text-sm text-gray-600 mb-3">{pricing.description}</p>
            <div className="flex justify-between items-center">
              <span className="text-2xl font-bold text-green-600">+${pricing.extraPrice}</span>
              <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                pricing.isActive 
                  ? 'bg-green-100 text-green-800'
                  : 'bg-red-100 text-red-800'
              }`}>
                {pricing.isActive ? 'Active' : 'Inactive'}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Modal Components with Image Upload Support
function AddMovieModal({ onClose, onAdd }: any) {
  const generateUploadUrl = useMutation(api.movies.generateUploadUrl);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    duration: "",
    genre: "",
    baseTicketPrice: "",
    rating: "",
    director: "",
    cast: "",
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setUploading(true);
    
    try {
      let posterId = undefined;
      
      // Upload poster if file is selected
      if (selectedFile) {
        const uploadUrl = await generateUploadUrl();
        const result = await fetch(uploadUrl, {
          method: "POST",
          headers: { "Content-Type": selectedFile.type },
          body: selectedFile,
        });
        const { storageId } = await result.json();
        posterId = storageId;
      }

      await onAdd({
        ...formData,
        duration: parseInt(formData.duration),
        baseTicketPrice: parseFloat(formData.baseTicketPrice),
        cast: formData.cast ? formData.cast.split(",").map((s: string) => s.trim()) : [],
        posterId,
        isActive: true,
      });
      onClose();
    } catch (error) {
      console.error("Failed to add movie:", error);
      alert("Failed to add movie. Please try again.");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Add New Movie</h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="text"
            placeholder="Movie Title"
            value={formData.title}
            onChange={(e) => setFormData({...formData, title: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <textarea
            placeholder="Description"
            value={formData.description}
            onChange={(e) => setFormData({...formData, description: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            rows={3}
            required
          />
          <input
            type="number"
            placeholder="Duration (minutes)"
            value={formData.duration}
            onChange={(e) => setFormData({...formData, duration: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <input
            type="text"
            placeholder="Genre"
            value={formData.genre}
            onChange={(e) => setFormData({...formData, genre: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <input
            type="number"
            step="0.01"
            placeholder="Base Ticket Price"
            value={formData.baseTicketPrice}
            onChange={(e) => setFormData({...formData, baseTicketPrice: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <input
            type="text"
            placeholder="Rating (e.g., PG-13)"
            value={formData.rating}
            onChange={(e) => setFormData({...formData, rating: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
          />
          <input
            type="text"
            placeholder="Director"
            value={formData.director}
            onChange={(e) => setFormData({...formData, director: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
          />
          <input
            type="text"
            placeholder="Cast (comma separated)"
            value={formData.cast}
            onChange={(e) => setFormData({...formData, cast: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
          />
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Movie Poster
            </label>
            <input
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
            />
            {selectedFile && (
              <p className="text-sm text-gray-600 mt-1">Selected: {selectedFile.name}</p>
            )}
          </div>
          <div className="flex gap-3">
            <button
              type="submit"
              disabled={uploading}
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
            >
              {uploading ? "Adding..." : "Add Movie"}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function EditMovieModal({ movie, onClose, onUpdate }: any) {
  const generateUploadUrl = useMutation(api.movies.generateUploadUrl);
  const [formData, setFormData] = useState({
    title: movie.title || "",
    description: movie.description || "",
    duration: movie.duration?.toString() || "",
    genre: movie.genre || "",
    baseTicketPrice: (movie.baseTicketPrice || movie.ticketPrice || "").toString(),
    rating: movie.rating || "",
    director: movie.director || "",
    cast: movie.cast?.join(", ") || "",
    isActive: movie.isActive,
  });
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setUploading(true);
    
    try {
      let posterId = movie.posterId;
      
      // Upload new poster if file is selected
      if (selectedFile) {
        const uploadUrl = await generateUploadUrl();
        const result = await fetch(uploadUrl, {
          method: "POST",
          headers: { "Content-Type": selectedFile.type },
          body: selectedFile,
        });
        const { storageId } = await result.json();
        posterId = storageId;
      }

      await onUpdate({
        movieId: movie._id,
        ...formData,
        duration: parseInt(formData.duration),
        baseTicketPrice: parseFloat(formData.baseTicketPrice),
        cast: formData.cast ? formData.cast.split(",").map((s: string) => s.trim()) : [],
        posterId,
      });
      onClose();
    } catch (error) {
      console.error("Failed to update movie:", error);
      alert("Failed to update movie. Please try again.");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md max-h-[90vh] overflow-y-auto">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Edit Movie</h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="text"
            placeholder="Movie Title"
            value={formData.title}
            onChange={(e) => setFormData({...formData, title: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <textarea
            placeholder="Description"
            value={formData.description}
            onChange={(e) => setFormData({...formData, description: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            rows={3}
            required
          />
          <input
            type="number"
            placeholder="Duration (minutes)"
            value={formData.duration}
            onChange={(e) => setFormData({...formData, duration: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <input
            type="text"
            placeholder="Genre"
            value={formData.genre}
            onChange={(e) => setFormData({...formData, genre: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <input
            type="number"
            step="0.01"
            placeholder="Base Ticket Price"
            value={formData.baseTicketPrice}
            onChange={(e) => setFormData({...formData, baseTicketPrice: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <input
            type="text"
            placeholder="Rating (e.g., PG-13)"
            value={formData.rating}
            onChange={(e) => setFormData({...formData, rating: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
          />
          <input
            type="text"
            placeholder="Director"
            value={formData.director}
            onChange={(e) => setFormData({...formData, director: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
          />
          <input
            type="text"
            placeholder="Cast (comma separated)"
            value={formData.cast}
            onChange={(e) => setFormData({...formData, cast: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
          />
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Movie Poster {movie.posterUrl && "(Current poster will be replaced)"}
            </label>
            <input
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-md"
            />
            {selectedFile && (
              <p className="text-sm text-gray-600 mt-1">Selected: {selectedFile.name}</p>
            )}
          </div>
          <label className="flex items-center">
            <input
              type="checkbox"
              checked={formData.isActive}
              onChange={(e) => setFormData({...formData, isActive: e.target.checked})}
              className="mr-2"
            />
            Active
          </label>
          <div className="flex gap-3">
            <button
              type="submit"
              disabled={uploading}
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
            >
              {uploading ? "Updating..." : "Update Movie"}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function AddTheaterModal({ onClose, onAdd, categoryPricing }: any) {
  const [formData, setFormData] = useState({
    name: "",
    capacity: "",
    category: "Standard",
    features: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await onAdd({
        ...formData,
        capacity: parseInt(formData.capacity),
        features: formData.features ? formData.features.split(",").map((s: string) => s.trim()) : [],
      });
      onClose();
    } catch (error) {
      console.error("Failed to add theater:", error);
      alert("Failed to add theater. Please try again.");
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Add New Theater</h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="text"
            placeholder="Theater Name"
            value={formData.name}
            onChange={(e) => setFormData({...formData, name: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <input
            type="number"
            placeholder="Capacity"
            value={formData.capacity}
            onChange={(e) => setFormData({...formData, capacity: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <select
            value={formData.category}
            onChange={(e) => setFormData({...formData, category: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          >
            {categoryPricing?.map((pricing: any) => (
              <option key={pricing._id} value={pricing.category}>
                {pricing.category} (+${pricing.extraPrice})
              </option>
            ))}
          </select>
          <input
            type="text"
            placeholder="Features (comma separated)"
            value={formData.features}
            onChange={(e) => setFormData({...formData, features: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
          />
          <div className="flex gap-3">
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Add Theater
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function EditTheaterModal({ theater, onClose, onUpdate, categoryPricing }: any) {
  const [formData, setFormData] = useState({
    name: theater.name || "",
    capacity: theater.capacity?.toString() || "",
    category: theater.category || "Standard",
    features: theater.features?.join(", ") || "",
    isActive: theater.isActive,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await onUpdate({
        theaterId: theater._id,
        ...formData,
        capacity: parseInt(formData.capacity),
        features: formData.features ? formData.features.split(",").map((s: string) => s.trim()) : [],
      });
      onClose();
    } catch (error) {
      console.error("Failed to update theater:", error);
      alert("Failed to update theater. Please try again.");
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Edit Theater</h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="text"
            placeholder="Theater Name"
            value={formData.name}
            onChange={(e) => setFormData({...formData, name: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <input
            type="number"
            placeholder="Capacity"
            value={formData.capacity}
            onChange={(e) => setFormData({...formData, capacity: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <select
            value={formData.category}
            onChange={(e) => setFormData({...formData, category: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          >
            {categoryPricing?.map((pricing: any) => (
              <option key={pricing._id} value={pricing.category}>
                {pricing.category} (+${pricing.extraPrice})
              </option>
            ))}
          </select>
          <input
            type="text"
            placeholder="Features (comma separated)"
            value={formData.features}
            onChange={(e) => setFormData({...formData, features: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
          />
          <label className="flex items-center">
            <input
              type="checkbox"
              checked={formData.isActive}
              onChange={(e) => setFormData({...formData, isActive: e.target.checked})}
              className="mr-2"
            />
            Active
          </label>
          <div className="flex gap-3">
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Update Theater
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function AddShowtimeModal({ onClose, onAdd, movies, theaters }: any) {
  const [formData, setFormData] = useState({
    movieId: "",
    theaterId: "",
    startTime: "",
    endTime: "",
    specialPricing: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await onAdd({
        ...formData,
        specialPricing: formData.specialPricing ? parseFloat(formData.specialPricing) : undefined,
      });
      onClose();
    } catch (error) {
      console.error("Failed to add showtime:", error);
      alert("Failed to add showtime. Please try again.");
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Add New Showtime</h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <select
            value={formData.movieId}
            onChange={(e) => setFormData({...formData, movieId: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          >
            <option value="">Select Movie</option>
            {movies?.filter((m: any) => m.isActive).map((movie: any) => (
              <option key={movie._id} value={movie._id}>
                {movie.title}
              </option>
            ))}
          </select>
          <select
            value={formData.theaterId}
            onChange={(e) => setFormData({...formData, theaterId: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          >
            <option value="">Select Theater</option>
            {theaters?.filter((t: any) => t.isActive).map((theater: any) => (
              <option key={theater._id} value={theater._id}>
                {theater.name} ({theater.category})
              </option>
            ))}
          </select>
          <input
            type="datetime-local"
            placeholder="Start Time"
            value={formData.startTime}
            onChange={(e) => setFormData({...formData, startTime: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <input
            type="datetime-local"
            placeholder="End Time"
            value={formData.endTime}
            onChange={(e) => setFormData({...formData, endTime: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <input
            type="number"
            step="0.01"
            placeholder="Special Pricing (optional)"
            value={formData.specialPricing}
            onChange={(e) => setFormData({...formData, specialPricing: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
          />
          <div className="flex gap-3">
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Add Showtime
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function EditShowtimeModal({ showtime, onClose, onUpdate, movies, theaters }: any) {
  const [formData, setFormData] = useState({
    movieId: showtime.movieId || "",
    theaterId: showtime.theaterId || "",
    startTime: showtime.startTime ? new Date(showtime.startTime).toISOString().slice(0, 16) : "",
    endTime: showtime.endTime ? new Date(showtime.endTime).toISOString().slice(0, 16) : "",
    specialPricing: showtime.specialPricing?.toString() || "",
    isActive: showtime.isActive,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await onUpdate({
        showtimeId: showtime._id,
        ...formData,
        specialPricing: formData.specialPricing ? parseFloat(formData.specialPricing) : undefined,
      });
      onClose();
    } catch (error) {
      console.error("Failed to update showtime:", error);
      alert("Failed to update showtime. Please try again.");
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Edit Showtime</h3>
        <form onSubmit={handleSubmit} className="space-y-4">
          <select
            value={formData.movieId}
            onChange={(e) => setFormData({...formData, movieId: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          >
            <option value="">Select Movie</option>
            {movies?.map((movie: any) => (
              <option key={movie._id} value={movie._id}>
                {movie.title}
              </option>
            ))}
          </select>
          <select
            value={formData.theaterId}
            onChange={(e) => setFormData({...formData, theaterId: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          >
            <option value="">Select Theater</option>
            {theaters?.map((theater: any) => (
              <option key={theater._id} value={theater._id}>
                {theater.name} ({theater.category})
              </option>
            ))}
          </select>
          <input
            type="datetime-local"
            placeholder="Start Time"
            value={formData.startTime}
            onChange={(e) => setFormData({...formData, startTime: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <input
            type="datetime-local"
            placeholder="End Time"
            value={formData.endTime}
            onChange={(e) => setFormData({...formData, endTime: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
            required
          />
          <input
            type="number"
            step="0.01"
            placeholder="Special Pricing (optional)"
            value={formData.specialPricing}
            onChange={(e) => setFormData({...formData, specialPricing: e.target.value})}
            className="w-full px-3 py-2 border border-gray-300 rounded-md"
          />
          <label className="flex items-center">
            <input
              type="checkbox"
              checked={formData.isActive}
              onChange={(e) => setFormData({...formData, isActive: e.target.checked})}
              className="mr-2"
            />
            Active
          </label>
          <div className="flex gap-3">
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              Update Showtime
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 bg-gray-300 text-gray-700 rounded-md hover:bg-gray-400"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
