import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState } from "react";
import { MovieBooking } from "./MovieBooking";

export function CustomerDashboard() {
  const movies = useQuery(api.movies.listActiveMovies);
  const userBookings = useQuery(api.bookings.getUserBookings);
  const [selectedMovie, setSelectedMovie] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<"browse" | "bookings">("browse");

  if (movies === undefined || userBookings === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (selectedMovie) {
    return (
      <MovieBooking
        movie={selectedMovie}
        onBack={() => setSelectedMovie(null)}
      />
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow-md p-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome to 3z Cinema</h1>
        <p className="text-gray-600">Discover and book your favorite movies</p>
      </div>

      {/* Navigation Tabs */}
      <div className="bg-white rounded-lg shadow-md">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {[
              { id: "browse", label: "Browse Movies", icon: "🎬" },
              { id: "bookings", label: "My Bookings", icon: "🎫" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === tab.id
                    ? "border-blue-500 text-blue-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                <span className="mr-2">{tab.icon}</span>
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === "browse" && (
            <BrowseMovies movies={movies} onSelectMovie={setSelectedMovie} />
          )}
          {activeTab === "bookings" && <MyBookings bookings={userBookings} />}
        </div>
      </div>
    </div>
  );
}

function BrowseMovies({ movies, onSelectMovie }: { movies: any[]; onSelectMovie: (movie: any) => void }) {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold text-gray-900">Now Showing</h2>
      
      {movies.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">🎬</div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No movies available</h3>
          <p className="text-gray-600">Check back later for new releases!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {movies.map((movie) => (
            <MovieCard key={movie._id} movie={movie} onSelect={() => onSelectMovie(movie)} />
          ))}
        </div>
      )}
    </div>
  );
}

function MovieCard({ movie, onSelect }: { movie: any; onSelect: () => void }) {
  return (
    <div className="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
      <div onClick={onSelect}>
        {movie.posterUrl ? (
          <img
            src={movie.posterUrl}
            alt={movie.title}
            className="w-full h-64 object-cover"
          />
        ) : (
          <div className="w-full h-64 bg-gray-200 flex items-center justify-center">
            <span className="text-4xl">🎬</span>
          </div>
        )}
        <div className="p-4">
          <h3 className="font-semibold text-gray-900 mb-2">{movie.title}</h3>
          <p className="text-sm text-gray-600 mb-2">{movie.genre} • {movie.duration} min</p>
          <p className="text-sm text-gray-600 mb-3 line-clamp-2">{movie.description}</p>
          <div className="flex justify-between items-center">
            <span className="text-lg font-bold text-green-600">From ${movie.baseTicketPrice}</span>
            <button className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 text-sm">
              Book Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function MyBookings({ bookings }: { bookings: any[] }) {
  const [showQRCode, setShowQRCode] = useState<string | null>(null);
  const bookingDetails = useQuery(
    api.bookings.getBookingByReference,
    showQRCode ? { reference: showQRCode } : "skip"
  );

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold text-gray-900">My Bookings</h2>
      
      {bookings.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">🎫</div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No bookings yet</h3>
          <p className="text-gray-600">Start by browsing our available movies!</p>
        </div>
      ) : (
        <div className="space-y-4">
          {bookings.map((booking) => (
            <BookingCard 
              key={booking._id} 
              booking={booking} 
              onShowQR={() => setShowQRCode(booking.bookingReference)}
            />
          ))}
        </div>
      )}

      {/* QR Code Modal */}
      {showQRCode && (
        <QRCodeModal
          bookingReference={showQRCode}
          bookingDetails={bookingDetails}
          onClose={() => setShowQRCode(null)}
        />
      )}
    </div>
  );
}

function BookingCard({ booking, onShowQR }: { booking: any; onShowQR: () => void }) {
  const showtime = booking.showtime;
  const startTime = showtime ? new Date(showtime.startTime) : null;

  return (
    <div className="bg-white border border-gray-200 rounded-lg p-6">
      <div className="flex justify-between items-start mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">{booking.movie?.title}</h3>
          <p className="text-sm text-gray-600">Booking Reference: {booking.bookingReference}</p>
        </div>
        <div className="flex items-center gap-3">
          <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
            booking.paymentStatus === "completed"
              ? "bg-green-100 text-green-800"
              : booking.paymentStatus === "pending"
              ? "bg-yellow-100 text-yellow-800"
              : "bg-red-100 text-red-800"
          }`}>
            {booking.paymentStatus}
          </span>
          {booking.paymentStatus === "completed" && (
            <button
              onClick={onShowQR}
              className="px-3 py-1 bg-blue-600 text-white text-xs rounded hover:bg-blue-700 flex items-center gap-1"
            >
              📱 Show QR
            </button>
          )}
        </div>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
        <div>
          <p className="text-gray-600">Date & Time</p>
          <p className="font-medium">
            {startTime ? startTime.toLocaleDateString() : "N/A"}
            <br />
            {startTime ? startTime.toLocaleTimeString() : "N/A"}
          </p>
        </div>
        <div>
          <p className="text-gray-600">Seats</p>
          <p className="font-medium">{booking.seats.join(", ")}</p>
        </div>
        <div>
          <p className="text-gray-600">Payment Method</p>
          <p className="font-medium">{booking.paymentMethod}</p>
        </div>
        <div>
          <p className="text-gray-600">Total Amount</p>
          <p className="font-medium text-green-600">${booking.totalAmount.toFixed(2)}</p>
        </div>
      </div>
    </div>
  );
}

function QRCodeModal({ 
  bookingReference, 
  bookingDetails, 
  onClose 
}: { 
  bookingReference: string; 
  bookingDetails: any; 
  onClose: () => void; 
}) {
  if (!bookingDetails) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
          <div className="flex justify-center items-center h-32">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Your QR Code</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 text-xl"
          >
            ×
          </button>
        </div>
        
        <div className="text-center">
          <div className="mb-4">
            <p className="text-sm text-gray-600 mb-2">Booking Reference:</p>
            <p className="font-mono font-bold text-lg">{bookingReference}</p>
          </div>
          
          {bookingDetails.qrCode && (
            <div className="mb-4">
              <img 
                src={bookingDetails.qrCode} 
                alt="Booking QR Code" 
                className="mx-auto border rounded"
              />
            </div>
          )}
          
          <div className="text-sm text-gray-600 space-y-1">
            <p><strong>Movie:</strong> {bookingDetails.movie?.title}</p>
            <p><strong>Theater:</strong> {bookingDetails.theater?.name}</p>
            <p><strong>Seats:</strong> {bookingDetails.seats.join(", ")}</p>
            <p><strong>Date:</strong> {new Date(bookingDetails.showtime?.startTime).toLocaleDateString()}</p>
            <p><strong>Time:</strong> {new Date(bookingDetails.showtime?.startTime).toLocaleTimeString()}</p>
          </div>
          
          <div className="mt-4 p-3 bg-blue-50 rounded text-xs text-blue-800">
            <p>Show this QR code at the cinema entrance for verification</p>
          </div>
        </div>
        
        <button
          onClick={onClose}
          className="w-full mt-4 px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700"
        >
          Close
        </button>
      </div>
    </div>
  );
}
