import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState } from "react";

interface RoleSelectionProps {
  onRoleSelect: (role: string) => void;
  isProfileSetup?: boolean;
}

export function RoleSelection({ onRoleSelect, isProfileSetup = false }: RoleSelectionProps) {
  const createOrUpdateProfile = useMutation(api.users.createOrUpdateProfile);
  const [selectedRole, setSelectedRole] = useState<string>("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phone, setPhone] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleRoleSelection = async (role: string) => {
    if (isProfileSetup) {
      setSelectedRole(role);
    } else {
      onRoleSelect(role);
    }
  };

  const handleProfileSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRole) return;

    setIsSubmitting(true);
    try {
      await createOrUpdateProfile({
        role: selectedRole,
        firstName: firstName || undefined,
        lastName: lastName || undefined,
        phone: phone || undefined,
      });
    } catch (error) {
      console.error("Failed to create profile:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isProfileSetup && selectedRole) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Complete Your Profile</h2>
        <form onSubmit={handleProfileSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Selected Role: {selectedRole === "admin" ? "Administrator" : "Customer"}
            </label>
          </div>
          
          <div>
            <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-2">
              First Name
            </label>
            <input
              type="text"
              id="firstName"
              value={firstName}
              onChange={(e) => setFirstName(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter your first name"
            />
          </div>

          <div>
            <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-2">
              Last Name
            </label>
            <input
              type="text"
              id="lastName"
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter your last name"
            />
          </div>

          <div>
            <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-2">
              Phone Number
            </label>
            <input
              type="tel"
              id="phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter your phone number"
            />
          </div>

          <div className="flex gap-3">
            <button
              type="button"
              onClick={() => setSelectedRole("")}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
            >
              Back
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
            >
              {isSubmitting ? "Creating..." : "Complete Setup"}
            </button>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
        {isProfileSetup ? "Choose Your Role" : "Select Your Role"}
      </h2>
      
      <div className="space-y-4">
        <button
          onClick={() => handleRoleSelection("customer")}
          className="w-full p-6 border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors group"
        >
          <div className="text-center">
            <div className="text-4xl mb-3">🎬</div>
            <h3 className="text-xl font-semibold text-gray-900 group-hover:text-blue-600">
              Customer
            </h3>
            <p className="text-gray-600 mt-2">
              Browse movies, book tickets, and manage your reservations
            </p>
          </div>
        </button>

        <button
          onClick={() => handleRoleSelection("admin")}
          className="w-full p-6 border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors group"
        >
          <div className="text-center">
            <div className="text-4xl mb-3">⚙️</div>
            <h3 className="text-xl font-semibold text-gray-900 group-hover:text-blue-600">
              Administrator
            </h3>
            <p className="text-gray-600 mt-2">
              Manage movies, showtimes, and view booking reports
            </p>
          </div>
        </button>
      </div>
    </div>
  );
}
